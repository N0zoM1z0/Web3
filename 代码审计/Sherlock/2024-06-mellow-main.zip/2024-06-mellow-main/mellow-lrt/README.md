# mellow-lrt
Mellow lrt constructor