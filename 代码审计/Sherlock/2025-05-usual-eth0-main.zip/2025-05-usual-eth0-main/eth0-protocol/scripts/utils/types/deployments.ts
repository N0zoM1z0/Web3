export type ScriptResult = {
  stdout: string;
  stderr: string | null;
};
