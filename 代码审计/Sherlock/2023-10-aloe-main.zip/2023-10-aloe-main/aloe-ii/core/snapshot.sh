#!/bin/bash

forge snapshot --match-contract ".*Gas"
