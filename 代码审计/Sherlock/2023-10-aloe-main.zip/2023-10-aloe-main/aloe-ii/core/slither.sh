#!/bin/bash

rm slither.results.sarif
slither .
