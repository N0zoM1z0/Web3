---
name: Audit item
about: These are the audit items that end up in the report
title: ""
labels: ""
assignees: ""
---

## Summary

## Vulnerability Detail

## Impact

## Code Snippet

## Tool used

Manual Review

## Recommendation
