# Manticore Exercises

- [Example](./example.md): Arithmetic overflow
- [Exercise 1](./exercise1.md): Arithmetic rounding
- [Exercise 2](./exercise2.md): Arithmetic overflow through multiple transactions
