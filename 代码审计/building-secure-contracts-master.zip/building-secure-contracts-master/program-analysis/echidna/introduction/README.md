# Introduction

Introductory materials for fuzzing and Echidna:

- [Installation](./installation.md)
- [Introduction to fuzzing](./fuzzing-introduction.md): A brief introduction to fuzzing
- [How to test a property](./how-to-test-a-property.md): Testing a property with Echidna
