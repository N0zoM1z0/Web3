let script = document.createElement("script");
script.src = "//js.hs-scripts.com/22554992.js";
document.body.append(script);

let script2 = document.createElement("script");
script2.src = "https://plausible.gateway.trailofbits.com/js/script.js";
script2.setAttribute("data-domain", "secure-contracts.com");
script2.setAttribute("defer", "defer");
document.body.append(script2);
