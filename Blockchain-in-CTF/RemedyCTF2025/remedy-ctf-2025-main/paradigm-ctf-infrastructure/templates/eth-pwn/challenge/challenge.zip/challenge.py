from ctf_launchers.pwn_launcher import PwnChallengeLauncher

PwnChallengeLauncher().run()
