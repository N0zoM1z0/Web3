# Sealevel Attacks

Examples of common exploits unique to the Solana programming model and recommended idioms for
avoiding these attacks using the Anchor framework.

The examples in this repo are purposefully not complete. Each program here is meant to showcase a
specific issue and recommended fix in isolation.
